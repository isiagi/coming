import React from 'react'


const SubHeader = () => {
  return (
    <div>SubHeader</div>
  )
}

export default SubHeader

