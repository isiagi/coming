import ComingSoon from "@/components/coming-soon";

export default function Home() {
  return (
  <ComingSoon />
  );
}
